/// <reference path="modules/typedjson-npm/index.d.ts" />
