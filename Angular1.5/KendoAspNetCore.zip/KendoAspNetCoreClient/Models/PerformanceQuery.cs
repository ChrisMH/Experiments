﻿namespace KendoAspNetCoreClient.Models
{
    public class PerformanceQuery
    {
        
    }
}