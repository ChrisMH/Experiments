﻿using System.ComponentModel;

namespace KendoAspNetCoreClient.Models
{
    public enum GridFilterType
    {
        [Description("Backlog")]
        Backlog,

        [Description("Performance")]
        Performance
    }
}