"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var moment = require("moment");
var Utilities_1 = require("../../app/Utilities");
var TestQueryClass = (function () {
    function TestQueryClass() {
    }
    TestQueryClass.prototype.equals = function (other) {
        return this.stringMember === other.stringMember &&
            this.intMember === other.intMember &&
            moment(this.dateMember).toISOString() === moment(other.dateMember).toISOString() &&
            this.boolMember === other.boolMember &&
            Utilities_1.Util.arraysEqual(this.intArrayMember, other.intArrayMember);
    };
    __decorate([
        Utilities_1.UrlQuery.UrlQueryParam(Utilities_1.UrlQuery.StringConverter, { urlKey: "sm" }), 
        __metadata('design:type', String)
    ], TestQueryClass.prototype, "stringMember", void 0);
    __decorate([
        Utilities_1.UrlQuery.UrlQueryParam(Utilities_1.UrlQuery.IntConverter, { urlKey: "im" }), 
        __metadata('design:type', Number)
    ], TestQueryClass.prototype, "intMember", void 0);
    __decorate([
        Utilities_1.UrlQuery.UrlQueryParam(Utilities_1.UrlQuery.IsoDateConverter), 
        __metadata('design:type', Date)
    ], TestQueryClass.prototype, "dateMember", void 0);
    __decorate([
        Utilities_1.UrlQuery.UrlQueryParam(Utilities_1.UrlQuery.BoolConverter), 
        __metadata('design:type', Boolean)
    ], TestQueryClass.prototype, "boolMember", void 0);
    __decorate([
        Utilities_1.UrlQuery.UrlQueryParam(Utilities_1.UrlQuery.IntArrayConverter), 
        __metadata('design:type', Array)
    ], TestQueryClass.prototype, "intArrayMember", void 0);
    __decorate([
        Utilities_1.UrlQuery.UrlQueryParam(Utilities_1.UrlQuery.StringConverter, { urlKey: "ro", readOnly: true }), 
        __metadata('design:type', String)
    ], TestQueryClass.prototype, "readOnlyMember", void 0);
    return TestQueryClass;
}());
describe("UrlQuery : ", function () {
    var fullQueryObject;
    var fullFromUrlObject;
    var fullToUrlObject;
    var emptyQueryObject;
    var emptyUrlObject;
    beforeAll(function () {
        fullQueryObject = new TestQueryClass();
        fullQueryObject.stringMember = "Hey";
        fullQueryObject.intMember = 47;
        fullQueryObject.dateMember = moment("2016-01-01T00:00:00Z").toDate();
        fullQueryObject.boolMember = true;
        fullQueryObject.intArrayMember = [4, 2, 5, 1];
        fullQueryObject.readOnlyMember = "Read Only";
        fullFromUrlObject = {
            sm: "Hey",
            im: "47",
            dateMember: moment("2016-01-01T00:00:00Z").toISOString(),
            boolMember: "t",
            intArrayMember: "4;2;5;1",
            ro: "Read Only"
        };
        fullToUrlObject = {
            sm: "Hey",
            im: "47",
            dateMember: moment("2016-01-01T00:00:00Z").toISOString(),
            boolMember: "t",
            intArrayMember: "4;2;5;1"
        };
        emptyQueryObject = new TestQueryClass();
        emptyUrlObject = {};
    });
    describe("UrlQueryParam decorator : ", function () {
        it("has metadata", function () {
            expect(Utilities_1.UrlQuery.getUrlParams(TestQueryClass.prototype).length).toBe(6);
        });
        it("metadata has correct propertyKeys", function () {
            var queryParams = Utilities_1.UrlQuery.getUrlParams(TestQueryClass.prototype);
            var propCount = 0;
            var _loop_1 = function(prop) {
                if (prop === "equals")
                    return "continue";
                expect(queryParams.find(function (v) { return v.propertyKey === prop; })).toBeDefined();
                propCount++;
            };
            for (var prop in fullQueryObject) {
                _loop_1(prop);
            }
            expect(propCount).toBeGreaterThanOrEqual(queryParams.length);
        });
        it("metadata has correct urlKeys", function () {
            var queryParams = Utilities_1.UrlQuery.getUrlParams(TestQueryClass.prototype);
            var propCount = 0;
            var _loop_2 = function(prop) {
                if (prop === "equals")
                    return "continue";
                var expectedUrlKey = "";
                var expectedReadOnly = false;
                switch (prop) {
                    case "stringMember":
                        expectedUrlKey = "sm";
                        break;
                    case "intMember":
                        expectedUrlKey = "im";
                        break;
                    case "dateMember":
                        expectedUrlKey = "dateMember";
                        break;
                    case "boolMember":
                        expectedUrlKey = "boolMember";
                        break;
                    case "intArrayMember":
                        expectedUrlKey = "intArrayMember";
                        break;
                    case "readOnlyMember":
                        expectedUrlKey = "ro";
                        expectedReadOnly = true;
                        break;
                }
                expect(queryParams.find(function (v) { return v.propertyKey === prop; }).urlKey).toEqual(expectedUrlKey);
                propCount++;
            };
            for (var prop in fullQueryObject) {
                _loop_2(prop);
            }
            expect(propCount).toBeGreaterThanOrEqual(queryParams.length);
        });
        it("metadata has converter", function () {
            var queryParams = Utilities_1.UrlQuery.getUrlParams(TestQueryClass.prototype);
            var propCount = 0;
            var _loop_3 = function(prop) {
                if (prop === "equals")
                    return "continue";
                expect(queryParams.find(function (v) { return v.propertyKey === prop; }).converter).toBeDefined();
                propCount++;
            };
            for (var prop in fullQueryObject) {
                _loop_3(prop);
            }
            expect(propCount).toBeGreaterThanOrEqual(queryParams.length);
        });
    });
    describe("converters : ", function () {
        it("can convert string from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "stringMember"; });
            var queryElements = { sm: "A String" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.stringMember).toBeDefined();
            expect(target.stringMember).toEqual("A String");
        });
        it("can convert string to URL", function () {
            var source = new TestQueryClass();
            source.stringMember = "A String";
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(source)
                .find(function (v) { return v.propertyKey === "stringMember"; });
            var result = {};
            queryParam.converter.toUrl(source, result, queryParam);
            expect(result).toEqual({ sm: "A String" });
        });
        it("can convert int from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "intMember"; });
            var queryElements = { im: 100 };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.intMember).toBeDefined();
            expect(target.intMember).toEqual(100);
        });
        it("can convert int to URL", function () {
            var source = new TestQueryClass();
            source.intMember = 100;
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(source)
                .find(function (v) { return v.propertyKey === "intMember"; });
            var result = {};
            queryParam.converter.toUrl(source, result, queryParam);
            expect(result).toEqual({ im: "100" });
        });
        it("can convert boolean t from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "boolMember"; });
            var queryElements = { boolMember: "t" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.boolMember).toBeDefined();
            expect(target.boolMember).toEqual(true);
        });
        it("can convert boolean true from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "boolMember"; });
            var queryElements = { boolMember: "true" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.boolMember).toBeDefined();
            expect(target.boolMember).toEqual(true);
        });
        it("can convert boolean True from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "boolMember"; });
            var queryElements = { boolMember: "True" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.boolMember).toBeDefined();
            expect(target.boolMember).toEqual(true);
        });
        it("can convert boolean f from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "boolMember"; });
            var queryElements = { boolMember: "f" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.boolMember).toBeDefined();
            expect(target.boolMember).toEqual(false);
        });
        it("can convert boolean false from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "boolMember"; });
            var queryElements = { boolMember: "false" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.boolMember).toBeDefined();
            expect(target.boolMember).toEqual(false);
        });
        it("can convert boolean False from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "boolMember"; });
            var queryElements = { boolMember: "False" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.boolMember).toBeDefined();
            expect(target.boolMember).toEqual(false);
        });
        it("can convert boolean garbage from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "boolMember"; });
            var queryElements = { boolMember: "DFWERCsfa" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.boolMember).toBeDefined();
            expect(target.boolMember).toEqual(false);
        });
        it("can convert boolean true to URL", function () {
            var source = new TestQueryClass();
            source.boolMember = true;
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(source)
                .find(function (v) { return v.propertyKey === "boolMember"; });
            var result = {};
            queryParam.converter.toUrl(source, result, queryParam);
            expect(result).toEqual({ boolMember: "t" });
        });
        it("can convert boolean false to URL", function () {
            var source = new TestQueryClass();
            source.boolMember = false;
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(source)
                .find(function (v) { return v.propertyKey === "boolMember"; });
            var result = {};
            queryParam.converter.toUrl(source, result, queryParam);
            expect(result).toEqual({ boolMember: "f" });
        });
        it("can convert ISO date from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "dateMember"; });
            var value = moment().toISOString();
            var queryElements = { dateMember: value };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.dateMember).toBeDefined();
            expect(moment(target.dateMember).toISOString()).toEqual(value);
        });
        it("can convert ISO date to URL", function () {
            var value = moment();
            var source = new TestQueryClass();
            source.dateMember = value.toDate();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(source)
                .find(function (v) { return v.propertyKey === "dateMember"; });
            var result = {};
            queryParam.converter.toUrl(source, result, queryParam);
            expect(result).toEqual({ dateMember: value.toISOString() });
        });
        it("can convert empty int array from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "intArrayMember"; });
            var queryElements = { intArrayMember: "" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.intArrayMember).toEqual([]);
        });
        it("can convert empty int array to URL", function () {
            var source = new TestQueryClass();
            source.intArrayMember = [];
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(source)
                .find(function (v) { return v.propertyKey === "intArrayMember"; });
            var result = {};
            queryParam.converter.toUrl(source, result, queryParam);
            expect(result).toEqual({});
        });
        it("can convert single int array from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "intArrayMember"; });
            var queryElements = { intArrayMember: "1" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.intArrayMember).toBeDefined();
            expect(target.intArrayMember).toEqual([1]);
        });
        it("can convert single int array to URL", function () {
            var source = new TestQueryClass();
            source.intArrayMember = [1];
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(source)
                .find(function (v) { return v.propertyKey === "intArrayMember"; });
            var result = {};
            queryParam.converter.toUrl(source, result, queryParam);
            expect(result).toEqual({ intArrayMember: "1" });
        });
        it("can convert int array from URL", function () {
            var target = new TestQueryClass();
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(target)
                .find(function (v) { return v.propertyKey === "intArrayMember"; });
            var queryElements = { intArrayMember: "1;5;10;-1" };
            queryParam.converter.fromUrl(queryElements, target, queryParam);
            expect(target.intArrayMember).toBeDefined();
            expect(target.intArrayMember).toEqual([1, 5, 10, -1]);
        });
        it("can convert int array to URL", function () {
            var source = new TestQueryClass();
            source.intArrayMember = [1, 5, 10, -1];
            var queryParam = Utilities_1.UrlQuery
                .getUrlParams(source)
                .find(function (v) { return v.propertyKey === "intArrayMember"; });
            var result = {};
            queryParam.converter.toUrl(source, result, queryParam);
            expect(result).toEqual({ intArrayMember: "1;5;10;-1" });
        });
    });
    describe("toUrl : ", function () {
        it("creates url object from full query object", function () {
            var result = Utilities_1.UrlQuery.toUrlObject(fullQueryObject);
            expect(result).toEqual(fullToUrlObject);
        });
        it("creates url object from empty query object", function () {
            var result = Utilities_1.UrlQuery.toUrlObject(new TestQueryClass());
            expect(result).toEqual(emptyUrlObject);
        });
    });
    describe("fromUrl : ", function () {
        it("creates query object from full url object", function () {
            var result = Utilities_1.UrlQuery.fromUrlObject(fullFromUrlObject, TestQueryClass);
            expect(result).toEqual(fullQueryObject);
        });
        it("creates query object from empty url object", function () {
            var result = Utilities_1.UrlQuery.fromUrlObject({}, TestQueryClass);
            expect(result).toEqual(emptyQueryObject);
        });
    });
});
//# sourceMappingURL=UrlQuery.test.js.map