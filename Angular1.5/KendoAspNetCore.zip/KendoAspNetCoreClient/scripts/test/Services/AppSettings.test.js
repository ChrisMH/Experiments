"use strict";
var angular = require("angular");
require("ngMock");
var Mocks_1 = require("../Mocks");
var Services_1 = require("../../app/Services");
angular.module("AppSettingsTestModule", [])
    .factory("configRoot", function () { return Mocks_1.configRoot; })
    .service("appSettings", Services_1.AppSettings);
describe("AppSettings : ", function () {
    describe("Happy Path : ", function () {
        beforeEach(function () {
            angular.mock.module("AppSettingsTestModule");
        });
        it("can create AppSettings", angular.mock.inject(function (appSettings) {
            expect(appSettings).toBeDefined();
        }));
        it("can create AppSettings.pageConfig with expected properties", angular.mock.inject(function (appSettings) {
            expect(appSettings.originUrl).toBeDefined();
            expect(appSettings.originUrl).toEqual(Mocks_1.configRoot["page"]["config"]["originUrl"]);
            expect(appSettings.rootUrl).toBeDefined();
            expect(appSettings.rootUrl).toEqual(Mocks_1.configRoot["page"]["config"]["rootUrl"]);
            expect(appSettings.version).toBeDefined();
            expect(appSettings.version).toEqual(Mocks_1.configRoot["page"]["config"]["version"]);
        }));
    });
    describe("Error Cases : ", function () {
        it("has undefined values when page is undefined", function () {
            angular.mock.module(function ($provide) {
                $provide.factory("configRoot", function () { return {}; });
                $provide.service("appSettings", Services_1.AppSettings);
            });
            angular.mock.inject(function (appSettings) {
                expect(appSettings).toBeDefined();
                expect(appSettings.originUrl).toBeUndefined();
                expect(appSettings.rootUrl).toBeUndefined();
                expect(appSettings.version).toBeUndefined();
            });
        });
        it("has undefined values config is undefined", function () {
            angular.mock.module(function ($provide) {
                $provide.factory("configRoot", function () { return { page: {} }; });
                $provide.service("appSettings", Services_1.AppSettings);
            });
            angular.mock.inject(function (appSettings) {
                expect(appSettings).toBeDefined();
                expect(appSettings.originUrl).toBeUndefined();
                expect(appSettings.rootUrl).toBeUndefined();
            });
        });
    });
});
//# sourceMappingURL=AppSettings.test.js.map