"use strict";
require("angular");
require("ngMock");
exports.configRoot = {
    page: {
        config: {
            originUrl: "http://origin/",
            rootUrl: "http://origin/root/",
            version: "1.0.0"
        }
    }
};
//# sourceMappingURL=ConfigRoot.js.map