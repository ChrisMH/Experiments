"use strict";
var angular = require("angular");
require("./Module");
angular.element(document.body).ready(function () {
    angular.bootstrap(document.body, ["Module"], { strictDi: true });
});
//# sourceMappingURL=main.js.map