"use strict";
var AngularUtil;
(function (AngularUtil) {
    var Directive = (function () {
        function Directive(controllerName, template, bindToController) {
            var _this = this;
            this.scope = {};
            this.bindToController = {};
            this.restrict = "E";
            this.replace = true;
            this.template = template;
            this.controller = controllerName;
            this.controllerAs = "ctrl" + controllerName;
            this.scope = {};
            this.bindToController = bindToController ? bindToController : {};
            this.name = controllerName.charAt(0).toLowerCase() + controllerName.slice(1);
            this.factory = function () { return _this; };
        }
        return Directive;
    }());
    AngularUtil.Directive = Directive;
})(AngularUtil = exports.AngularUtil || (exports.AngularUtil = {}));
//# sourceMappingURL=AngularUtil.js.map