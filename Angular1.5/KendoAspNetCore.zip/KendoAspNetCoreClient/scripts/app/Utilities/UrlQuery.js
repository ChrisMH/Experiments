"use strict";
require("reflect-metadata");
var moment = require("moment");
var UrlQuery;
(function (UrlQuery) {
    var UrlQueryKey = "UrlQueryKey";
    var UrlQueryParamConfiguration = (function () {
        function UrlQueryParamConfiguration() {
        }
        return UrlQueryParamConfiguration;
    }());
    UrlQuery.UrlQueryParamConfiguration = UrlQueryParamConfiguration;
    function UrlQueryParam(converterFactory, config) {
        return function (target, propertyKey) {
            var _config = config || new UrlQueryParamConfiguration();
            if (_config.urlKey === undefined)
                _config.urlKey = propertyKey;
            if (_config.readOnly === undefined)
                _config.readOnly = false;
            if (converterFactory == null)
                throw "UrlQueryParam: converterFactory is undefined for urlKey '" + _config.urlKey + "'";
            var classData = Reflect.getMetadata(UrlQueryKey, target);
            if (!classData) {
                classData = new UrlQueryClassMetadata();
                Reflect.defineMetadata(UrlQueryKey, classData, target);
            }
            var urlParam = new UrlQueryParamMetadata(_config.urlKey, _config.readOnly, propertyKey, new converterFactory());
            classData.urlParams.push(urlParam);
        };
    }
    UrlQuery.UrlQueryParam = UrlQueryParam;
    function toUrlObject(query) {
        var urlParams = UrlQuery.getUrlParams(query);
        var result = {};
        for (var i = 0; i < urlParams.length; i++) {
            if (urlParams[i].readOnly || !urlParams[i].converter)
                continue;
            urlParams[i].converter.toUrl(query, result, urlParams[i]);
        }
        return result;
    }
    UrlQuery.toUrlObject = toUrlObject;
    function fromUrlObject(params, resultType) {
        var result = new resultType();
        var urlParams = UrlQuery.getUrlParams(result);
        for (var i = 0; i < urlParams.length; i++) {
            if (!urlParams[i].converter)
                continue;
            urlParams[i].converter.fromUrl(params, result, urlParams[i]);
        }
        return result;
    }
    UrlQuery.fromUrlObject = fromUrlObject;
    function queryStringToUrlObject(queryString) {
        var result = new Object();
        var queryElements = queryString.split("&");
        for (var i = 0; i < queryElements.length; i++) {
            var keyValue = queryElements[i].split("=");
            if (keyValue.length === 1)
                result[keyValue[0]] = keyValue[0];
            else if (keyValue.length === 2)
                result[keyValue[0]] = keyValue[1];
        }
        return result;
    }
    UrlQuery.queryStringToUrlObject = queryStringToUrlObject;
    function getUrlParams(target) {
        var meta = Reflect.getMetadata(UrlQueryKey, target);
        if (!meta)
            return new Array();
        return meta.urlParams;
    }
    UrlQuery.getUrlParams = getUrlParams;
    var UrlQueryClassMetadata = (function () {
        function UrlQueryClassMetadata() {
            this.urlParams = new Array();
        }
        return UrlQueryClassMetadata;
    }());
    UrlQuery.UrlQueryClassMetadata = UrlQueryClassMetadata;
    var UrlQueryParamMetadata = (function () {
        function UrlQueryParamMetadata(urlKey, readOnly, propertyKey, converter) {
            this.urlKey = urlKey;
            this.readOnly = readOnly;
            this.propertyKey = propertyKey;
            this.converter = converter;
        }
        return UrlQueryParamMetadata;
    }());
    UrlQuery.UrlQueryParamMetadata = UrlQueryParamMetadata;
    var StringConverter = (function () {
        function StringConverter() {
        }
        StringConverter.prototype.toUrl = function (source, target, pi) {
            if (!source.hasOwnProperty(pi.propertyKey) || source[pi.propertyKey] === undefined)
                return;
            target[pi.urlKey] = source[pi.propertyKey];
        };
        StringConverter.prototype.fromUrl = function (source, target, pi) {
            var value = source.hasOwnProperty(pi.urlKey) ? source[pi.urlKey] : undefined;
            if (value !== undefined)
                target[pi.propertyKey] = value;
        };
        return StringConverter;
    }());
    UrlQuery.StringConverter = StringConverter;
    var IntConverter = (function () {
        function IntConverter() {
        }
        IntConverter.prototype.toUrl = function (source, target, pi) {
            if (!source.hasOwnProperty(pi.propertyKey) || source[pi.propertyKey] === undefined)
                return;
            target[pi.urlKey] = source[pi.propertyKey].toString();
        };
        IntConverter.prototype.fromUrl = function (source, target, pi) {
            var value = source.hasOwnProperty(pi.urlKey) ? source[pi.urlKey] : undefined;
            if (value !== undefined)
                target[pi.propertyKey] = parseInt(value);
        };
        return IntConverter;
    }());
    UrlQuery.IntConverter = IntConverter;
    var BoolConverter = (function () {
        function BoolConverter() {
        }
        BoolConverter.prototype.toUrl = function (source, target, pi) {
            if (!source.hasOwnProperty(pi.propertyKey) || source[pi.propertyKey] === undefined)
                return;
            target[pi.urlKey] = source[pi.propertyKey] === true ? "t" : "f";
        };
        BoolConverter.prototype.fromUrl = function (source, target, pi) {
            var value = source.hasOwnProperty(pi.urlKey) ? source[pi.urlKey] : undefined;
            if (value !== undefined)
                target[pi.propertyKey] = (value === "True" || value == "true" || value === "t") ? true : false;
        };
        return BoolConverter;
    }());
    UrlQuery.BoolConverter = BoolConverter;
    var IsoDateConverter = (function () {
        function IsoDateConverter() {
        }
        IsoDateConverter.prototype.toUrl = function (source, target, pi) {
            if (!source.hasOwnProperty(pi.propertyKey) || source[pi.propertyKey] === undefined)
                return;
            target[pi.urlKey] = moment(source[pi.propertyKey]).toISOString();
        };
        IsoDateConverter.prototype.fromUrl = function (source, target, pi) {
            var value = source.hasOwnProperty(pi.urlKey) ? source[pi.urlKey] : undefined;
            if (value !== undefined)
                target[pi.propertyKey] = moment(value).toDate();
        };
        return IsoDateConverter;
    }());
    UrlQuery.IsoDateConverter = IsoDateConverter;
    var IntArrayConverter = (function () {
        function IntArrayConverter() {
        }
        IntArrayConverter.prototype.toUrl = function (source, target, pi) {
            if (!source.hasOwnProperty(pi.propertyKey) || source[pi.propertyKey] === undefined
                || !(source[pi.propertyKey] instanceof Array) || source[pi.propertyKey].length === 0)
                return;
            target[pi.urlKey] = source[pi.propertyKey].join(";");
        };
        IntArrayConverter.prototype.fromUrl = function (source, target, pi) {
            var value = source.hasOwnProperty(pi.urlKey) ? source[pi.urlKey] : undefined;
            if (value !== undefined) {
                var array_1 = [];
                if (value.length > 0) {
                    var elements = value.split(";");
                    elements.forEach(function (e) { return array_1.push(parseInt(e)); });
                }
                target[pi.propertyKey] = array_1;
            }
        };
        return IntArrayConverter;
    }());
    UrlQuery.IntArrayConverter = IntArrayConverter;
})(UrlQuery = exports.UrlQuery || (exports.UrlQuery = {}));
//# sourceMappingURL=UrlQuery.js.map