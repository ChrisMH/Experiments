"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
require("kendo");
var typedjson_npm_1 = require("typedjson-npm");
var KendoUtil;
(function (KendoUtil) {
    var DropdownValue = (function () {
        function DropdownValue() {
        }
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', Number)
        ], DropdownValue.prototype, "id", void 0);
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', String)
        ], DropdownValue.prototype, "name", void 0);
        DropdownValue = __decorate([
            typedjson_npm_1.JsonObject, 
            __metadata('design:paramtypes', [])
        ], DropdownValue);
        return DropdownValue;
    }());
    KendoUtil.DropdownValue = DropdownValue;
    var DropdownConfig = (function () {
        function DropdownConfig() {
        }
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', Number)
        ], DropdownConfig.prototype, "default", void 0);
        __decorate([
            typedjson_npm_1.JsonMember({ elements: DropdownValue }), 
            __metadata('design:type', Array)
        ], DropdownConfig.prototype, "values", void 0);
        DropdownConfig = __decorate([
            typedjson_npm_1.JsonObject, 
            __metadata('design:paramtypes', [])
        ], DropdownConfig);
        return DropdownConfig;
    }());
    KendoUtil.DropdownConfig = DropdownConfig;
    var GridColumn = (function () {
        function GridColumn(field, title, type, width, format, aggregate, footerHeader, hidden) {
            this.field = field;
            this.title = title;
            this.type = type;
            this.width = typeof width === "number" ? width.toString() : width;
            this.format = format;
            this.aggregate = aggregate;
            this.footerHeader = footerHeader;
            this.hidden = hidden;
        }
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', String)
        ], GridColumn.prototype, "field", void 0);
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', String)
        ], GridColumn.prototype, "title", void 0);
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', String)
        ], GridColumn.prototype, "type", void 0);
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', String)
        ], GridColumn.prototype, "width", void 0);
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', String)
        ], GridColumn.prototype, "format", void 0);
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', String)
        ], GridColumn.prototype, "aggregate", void 0);
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', String)
        ], GridColumn.prototype, "footerHeader", void 0);
        __decorate([
            typedjson_npm_1.JsonMember, 
            __metadata('design:type', Boolean)
        ], GridColumn.prototype, "hidden", void 0);
        GridColumn = __decorate([
            typedjson_npm_1.JsonObject, 
            __metadata('design:paramtypes', [String, String, String, Object, String, String, String, Boolean])
        ], GridColumn);
        return GridColumn;
    }());
    KendoUtil.GridColumn = GridColumn;
    var GridConfig = (function () {
        function GridConfig() {
        }
        __decorate([
            typedjson_npm_1.JsonMember({ elements: GridColumn }), 
            __metadata('design:type', Array)
        ], GridConfig.prototype, "columns", void 0);
        GridConfig = __decorate([
            typedjson_npm_1.JsonObject, 
            __metadata('design:paramtypes', [])
        ], GridConfig);
        return GridConfig;
    }());
    KendoUtil.GridConfig = GridConfig;
    function resizeGrid(selector) {
        var gridElement = $(selector);
        var dataArea = gridElement.find(".k-grid-content");
        var gridHeight = gridElement.innerHeight();
        var otherElements = gridElement.children().not(".k-grid-content");
        var otherElementsHeight = 0;
        otherElements.each(function (i, elem) {
            otherElementsHeight += $(elem).outerHeight();
        });
        dataArea.height(gridHeight - otherElementsHeight);
    }
    KendoUtil.resizeGrid = resizeGrid;
    function createFilterParameterMap(root, data, dest) {
        if (data.logic)
            dest[(root + ".logic")] = data.logic;
        if (data.field)
            dest[(root + ".field")] = data.field;
        if (data.operator)
            dest[(root + ".operator")] = data.operator;
        if (data.value)
            dest[(root + ".value")] = data.value;
        if (data.filters) {
            data.filters.forEach(function (value, index) {
                var nextRoot = root + ".filters[" + index + "]";
                createFilterParameterMap(nextRoot, value, dest);
            });
        }
    }
    function createParameterMap(data, type) {
        var result = data;
        delete result["pageSize"];
        delete result["page"];
        if (result.sort) {
            result.sort.forEach(function (value, index) {
                result[("sort[" + index + "].field")] = value.field;
                result[("sort[" + index + "].dir")] = value.dir;
            });
            delete result["sort"];
        }
        if (result.aggregate) {
            result.aggregate.forEach(function (value, index) {
                result[("aggregate[" + index + "].field")] = value.field;
                result[("aggregate[" + index + "].aggregate")] = value.aggregate;
            });
            delete result["aggregate"];
        }
        if (result.filter) {
            createFilterParameterMap("filter", result.filter, result);
            delete result["filter"];
        }
        return result;
    }
    KendoUtil.createParameterMap = createParameterMap;
    function createColumn(gridColumn) {
        if (!gridColumn)
            return null;
        switch (gridColumn.type) {
            case "number":
                return KendoUtil.createNumberColumn(gridColumn);
            case "string":
                return KendoUtil.createStringColumn(gridColumn);
            case "boolean":
                return KendoUtil.createBooleanColumn(gridColumn);
            case "Date":
                return KendoUtil.createDateColumn(gridColumn);
            default:
                return null;
        }
    }
    KendoUtil.createColumn = createColumn;
    function createColumns(gridColumns) {
        var columns = [];
        gridColumns.forEach(function (gridColumn) {
            var column = createColumn(gridColumn);
            if (column)
                columns.push(column);
        });
        return columns;
    }
    KendoUtil.createColumns = createColumns;
    function createFields(gridColumns) {
        var fields = {};
        gridColumns.forEach(function (gridColumn) {
            if (gridColumn.type)
                fields[gridColumn.field] = { type: gridColumn.type };
        });
        return fields;
    }
    KendoUtil.createFields = createFields;
    function createAggregates(gridColumns) {
        var aggregates = [];
        gridColumns.forEach(function (column) {
            if (column.aggregate)
                aggregates.push({ field: column.field, aggregate: column.aggregate });
        });
        return aggregates;
    }
    KendoUtil.createAggregates = createAggregates;
    function parseWidth(width) {
        if (typeof width === "number")
            return width;
        var intWidth = parseInt(width);
        if (isNaN(intWidth))
            return width;
        return intWidth;
    }
    function createFooterTemplate(column) {
        if (!column.aggregate)
            return undefined;
        if (column.footerHeader && column.format)
            return "<div style='text-align:right'>#='" + column.footerHeader + " '.concat(kendo.toString(" + column.aggregate + ", '" + column.format + "'))#</div>";
        else if (column.footerHeader)
            return "<div style='text-align:right'>#='" + column.footerHeader + " '.concat(" + column.aggregate + ")#</div>";
        else if (column.format)
            return "<div style='text-align:right'>#=kendo.toString(" + column.aggregate + ", '" + column.format + "')#</div>";
        return "<div style='text-align:right'>#=" + column.aggregate + "#</div>";
    }
    function createStringColumn(column) {
        return {
            field: column.field,
            title: column.title,
            width: parseWidth(column.width),
            footerTemplate: createFooterTemplate(column),
            hidden: column.hidden ? column.hidden : false
        };
    }
    KendoUtil.createStringColumn = createStringColumn;
    function createNumberColumn(column) {
        return {
            field: column.field,
            title: column.title,
            width: parseWidth(column.width),
            template: "<div style='text-align:right'>#=kendo.toString(" + column.field + ", '" + column.format + "')#</div>",
            footerTemplate: createFooterTemplate(column),
            filterable: { ui: function (el) { return el.kendoNumericTextBox({ format: "\"" + column.format + "\"" }); } },
            hidden: column.hidden ? column.hidden : false
        };
    }
    KendoUtil.createNumberColumn = createNumberColumn;
    function createBooleanColumn(column) {
        return {
            field: column.field,
            title: column.title,
            width: parseWidth(column.width),
            template: "#=" + column.field + " ? 'Yes' : 'No'#",
            hidden: column.hidden ? column.hidden : false
        };
    }
    KendoUtil.createBooleanColumn = createBooleanColumn;
    function createDateColumn(column) {
        return {
            field: column.field,
            title: column.title,
            width: parseWidth(column.width),
            template: "<div style='text-align:right'>#=kendo.toString(kendo.parseDate(" + column.field + "), '" + column.format + "')#</div>",
            hidden: column.hidden ? column.hidden : false
        };
    }
    KendoUtil.createDateColumn = createDateColumn;
})(KendoUtil = exports.KendoUtil || (exports.KendoUtil = {}));
//# sourceMappingURL=KendoUtil.js.map