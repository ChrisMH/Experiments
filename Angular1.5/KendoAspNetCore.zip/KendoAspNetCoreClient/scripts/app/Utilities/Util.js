"use strict";
var Util;
(function (Util) {
    var Equatable = (function () {
        function Equatable() {
        }
        Equatable.prototype.equals = function (other) { return false; };
        return Equatable;
    }());
    Util.Equatable = Equatable;
    function arraysEqual(left, right) {
        if (!left && !right)
            return true;
        if (left && !right || !left && right)
            return false;
        if (left.length !== right.length)
            return false;
        for (var i = 0; i < left.length; i++) {
            if (left[i] instanceof Array && right[i] instanceof Array) {
                if (!arraysEqual(left[i], right[i]))
                    return false;
            }
            if (left[i] instanceof Equatable && right[i] instanceof Equatable) {
                return left[i].equals(right[i]);
            }
            else if (left[i] !== right[i]) {
                return false;
            }
        }
        return true;
    }
    Util.arraysEqual = arraysEqual;
})(Util = exports.Util || (exports.Util = {}));
//# sourceMappingURL=Util.js.map