"use strict";
var angular = require("angular");
require("kendo");
var Router_1 = require("./Router");
var Components_1 = require("./Components");
var Services_1 = require("./Services");
angular.module("Module", [
    "kendo.directives",
    "ui.router"
])
    .config(Router_1.Router.routes)
    .factory("configRoot", function () { return window; })
    .controller("Main", Components_1.Main)
    .controller("Charts", Components_1.Charts)
    .controller("Grid", Components_1.Grid)
    .service("appSettings", Services_1.AppSettings)
    .service("httpService", Services_1.HttpService);
//# sourceMappingURL=Module.js.map