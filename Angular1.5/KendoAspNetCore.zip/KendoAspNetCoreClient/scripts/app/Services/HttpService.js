"use strict";
var HttpService = (function () {
    function HttpService($http, $q) {
        this.$http = $http;
        this.$q = $q;
    }
    HttpService.prototype.get = function (url, transformResponse, params) {
        var _this = this;
        return this.$q(function (resolve, reject) {
            _this.$http({
                method: "GET",
                url: url,
                params: params,
                transformResponse: transformResponse
            })
                .then(function (response) {
                if (response.data.success && response.data.data)
                    resolve(response.data.data);
                else
                    reject(response.data.message);
            }, function (reason) {
                console.error(reason);
                reject(reason);
            });
        });
    };
    HttpService.prototype.$get = function () {
        return new HttpService(this.$http, this.$q);
    };
    HttpService.$inject = ["$http", "$q"];
    return HttpService;
}());
exports.HttpService = HttpService;
//# sourceMappingURL=HttpService.js.map