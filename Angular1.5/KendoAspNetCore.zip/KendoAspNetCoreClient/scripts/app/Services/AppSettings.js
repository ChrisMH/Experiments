"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var typedjson_npm_1 = require("typedjson-npm");
var AppSettings = (function () {
    function AppSettings(configRoot) {
        this.configRoot = configRoot;
        if (configRoot.hasOwnProperty("page") && configRoot["page"].hasOwnProperty("config")) {
            var pageConfig = typedjson_npm_1.TypedJSON.parse(typedjson_npm_1.TypedJSON.stringify(configRoot["page"]["config"]), PageConfig);
            this.originUrl = pageConfig.originUrl;
            this.rootUrl = pageConfig.rootUrl;
            this.version = pageConfig.version;
        }
    }
    AppSettings.prototype.$get = function () {
        return new AppSettings(this.configRoot);
    };
    AppSettings.$inject = ["configRoot"];
    return AppSettings;
}());
exports.AppSettings = AppSettings;
var PageConfig = (function () {
    function PageConfig() {
    }
    __decorate([
        typedjson_npm_1.JsonMember, 
        __metadata('design:type', String)
    ], PageConfig.prototype, "originUrl", void 0);
    __decorate([
        typedjson_npm_1.JsonMember, 
        __metadata('design:type', String)
    ], PageConfig.prototype, "rootUrl", void 0);
    __decorate([
        typedjson_npm_1.JsonMember, 
        __metadata('design:type', String)
    ], PageConfig.prototype, "version", void 0);
    PageConfig = __decorate([
        typedjson_npm_1.JsonObject, 
        __metadata('design:paramtypes', [])
    ], PageConfig);
    return PageConfig;
}());
exports.PageConfig = PageConfig;
//# sourceMappingURL=AppSettings.js.map