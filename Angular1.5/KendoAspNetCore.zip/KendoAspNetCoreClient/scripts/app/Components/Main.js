"use strict";
require("angular-ui-router");
var moment = require("moment");
require("./Main.css");
var Main = (function () {
    function Main($scope, $state, appSettings) {
        this.$scope = $scope;
        this.$state = $state;
        this.appSettings = appSettings;
        this.loadTime = moment().toDate();
    }
    Main.prototype.$onInit = function () {
        console.log("Main.$onInit:");
        console.log("  originUrl=" + this.appSettings.originUrl);
        console.log("  rootUrl=" + this.appSettings.rootUrl);
        console.log("  version=" + this.appSettings.version);
    };
    Main.$inject = ["$scope", "$state", "appSettings"];
    return Main;
}());
exports.Main = Main;
//# sourceMappingURL=Main.js.map