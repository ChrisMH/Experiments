"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
require("kendo");
var typedjson_npm_1 = require("typedjson-npm");
var Utilities_1 = require("../../Utilities");
require("./Grid.css");
var Grid = (function () {
    function Grid($timeout, appSettings, httpService) {
        this.$timeout = $timeout;
        this.appSettings = appSettings;
        this.httpService = httpService;
    }
    Grid.prototype.$onInit = function () {
        var _this = this;
        this.httpService.get(this.appSettings.rootUrl.concat("api/Grid/FilterConfig"), function (data) { return data ? typedjson_npm_1.TypedJSON.parse(data, FilterConfigResponse) : null; })
            .then(function (result) {
            _this.filterOptions = _this.createFilterOptions(result);
            _this.$timeout(function () { return _this.refreshGrid(); });
        });
    };
    Grid.prototype.refreshGrid = function () {
        var _this = this;
        var gridQuery = new GridQuery();
        gridQuery.filter = parseInt(this.filter.value());
        this.httpService.get(this.appSettings.rootUrl.concat("api/Grid/GridConfig"), function (data) { return data ? typedjson_npm_1.TypedJSON.parse(data, GridConfigResponse) : null; }, Utilities_1.UrlQuery.toUrlObject(gridQuery))
            .then(function (result) {
            _this.gridOptions = _this.createGridOptions(result);
        });
    };
    Grid.prototype.onFilterChanged = function (e) {
        this.refreshGrid();
    };
    Grid.prototype.createFilterOptions = function (config) {
        var _this = this;
        var index = config.values.findIndex(function (value) { return value.id === config.default; });
        return {
            dataValueField: "id",
            dataTextField: "name",
            dataSource: { data: config.values },
            index: index,
            change: function (e) { return _this.onFilterChanged(e); }
        };
    };
    Grid.prototype.createGridOptions = function (config) {
        var _this = this;
        var dataSourceOptions = {
            serverAggregates: true,
            serverFiltering: true,
            serverGrouping: true,
            serverPaging: true,
            serverSorting: true,
            pageSize: 25,
            transport: {
                read: {
                    url: function () { return (_this.appSettings.rootUrl + "api/Grid/Data"); },
                    dataType: "json"
                },
                parameterMap: function (data, type) { return Utilities_1.KendoUtil.createParameterMap(data, type); }
            },
            schema: {
                data: function (response) { return response["data"]["data"]; },
                total: function (response) { return response["data"]["count"]; },
                aggregates: function (response) { return response["data"]["aggregates"]; },
                model: { fields: Utilities_1.KendoUtil.createFields(config.columns) }
            },
            sort: { field: "customerName", dir: "asc" },
            aggregate: Utilities_1.KendoUtil.createAggregates(config.columns)
        };
        var options = {
            columns: Utilities_1.KendoUtil.createColumns(config.columns),
            filterable: { extra: false },
            pageable: {
                refresh: true,
                pageSizes: true,
                buttonCount: 5
            },
            scrollable: true,
            sortable: true,
            autoBind: true,
            dataSource: kendo.data.DataSource.create(dataSourceOptions)
        };
        return options;
    };
    Grid.$inject = ["$timeout", "appSettings", "httpService"];
    return Grid;
}());
exports.Grid = Grid;
var GridQuery = (function () {
    function GridQuery() {
    }
    __decorate([
        Utilities_1.UrlQuery.UrlQueryParam(Utilities_1.UrlQuery.IntConverter), 
        __metadata('design:type', Number)
    ], GridQuery.prototype, "filter", void 0);
    return GridQuery;
}());
var FilterConfigResponse = (function () {
    function FilterConfigResponse() {
    }
    __decorate([
        typedjson_npm_1.JsonMember, 
        __metadata('design:type', Boolean)
    ], FilterConfigResponse.prototype, "success", void 0);
    __decorate([
        typedjson_npm_1.JsonMember, 
        __metadata('design:type', String)
    ], FilterConfigResponse.prototype, "message", void 0);
    __decorate([
        typedjson_npm_1.JsonMember, 
        __metadata('design:type', Utilities_1.KendoUtil.DropdownConfig)
    ], FilterConfigResponse.prototype, "data", void 0);
    FilterConfigResponse = __decorate([
        typedjson_npm_1.JsonObject, 
        __metadata('design:paramtypes', [])
    ], FilterConfigResponse);
    return FilterConfigResponse;
}());
var GridConfigResponse = (function () {
    function GridConfigResponse() {
    }
    __decorate([
        typedjson_npm_1.JsonMember, 
        __metadata('design:type', Boolean)
    ], GridConfigResponse.prototype, "success", void 0);
    __decorate([
        typedjson_npm_1.JsonMember, 
        __metadata('design:type', String)
    ], GridConfigResponse.prototype, "message", void 0);
    __decorate([
        typedjson_npm_1.JsonMember, 
        __metadata('design:type', Utilities_1.KendoUtil.GridConfig)
    ], GridConfigResponse.prototype, "data", void 0);
    GridConfigResponse = __decorate([
        typedjson_npm_1.JsonObject, 
        __metadata('design:paramtypes', [])
    ], GridConfigResponse);
    return GridConfigResponse;
}());
//# sourceMappingURL=Grid.js.map