"use strict";
require("./AreaChart.css");
var AreaChartDirective = (function () {
    function AreaChartDirective() {
        this.restrict = "E";
        this.replace = true;
        this.template = require("./AreaChart.html");
        this.controller = "AreaChart";
        this.controllerAs = "ctrlAreaChart";
        this.scope = {};
        this.bindToController = {};
    }
    AreaChartDirective.factory = function () {
        return function () { return new AreaChartDirective(); };
    };
    return AreaChartDirective;
}());
exports.AreaChartDirective = AreaChartDirective;
var AreaChart = (function () {
    function AreaChart() {
    }
    return AreaChart;
}());
exports.AreaChart = AreaChart;
//# sourceMappingURL=AreaChart.js.map